# Affiliate Video Studio — Prototype v1

Prototype aplikasi Android/PWA untuk workflow affiliate Shopee.

## Fitur v1
- Input nama produk, harga/promo, durasi, dan gaya video.
- Upload beberapa foto produk.
- Menghasilkan 3 konsep/script otomatis berdasarkan template.
- Preview video 9:16.
- Export video WebM langsung dari browser Android.
- Bisa dipasang ke Home Screen sebagai PWA saat dibuka dari HTTPS/localhost.

## Catatan
Ini adalah prototype lokal dan belum terhubung ke API AI/generator video cloud. Versi berikutnya bisa ditambahkan AI sungguhan, text-to-speech, template motion yang lebih banyak, musik, subtitle otomatis, dan export MP4.

## Cara menjalankan
1. Buka folder ini lewat server HTTPS/localhost.
2. Di Android Chrome, buka alamatnya lalu pilih Add to Home screen/Install app.
3. Upload foto produk dan tekan Buat 3 konsep + video.
