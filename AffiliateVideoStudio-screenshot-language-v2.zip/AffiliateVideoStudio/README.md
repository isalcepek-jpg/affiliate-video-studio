# Affiliate Video Studio v2

Pembaruan:
- Upload 1 screenshot produk sebagai visual utama video.
- Bisa upload beberapa screenshot/foto untuk slideshow.
- Pilihan bahasa: Indonesia, English, Melayu, Español, Português.
- Script affiliate otomatis dibuat berdasarkan nama produk, harga/promo, gaya video, dan bahasa.
- Preview video 9:16.
- Export video WebM langsung dari browser.

Catatan: versi ini membuat video slideshow dari screenshot/foto yang diunggah. Untuk text-to-speech/voice-over otomatis dan generasi video AI yang benar-benar mengubah gambar menjadi adegan bergerak, diperlukan engine/API tambahan.
